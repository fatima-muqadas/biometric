import { Fingerprint } from './fingerprint.model';

describe('Fingerprint', () => {
  it('should create an instance', () => {
    expect(new Fingerprint()).toBeTruthy();
  });
});
