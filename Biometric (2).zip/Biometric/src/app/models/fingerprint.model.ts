export class Fingerprint {
    id?: string;
    db?: string;
}

