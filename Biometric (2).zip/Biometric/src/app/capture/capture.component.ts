import { Component, OnInit } from '@angular/core';
import { FingerprintService } from '../services/fingerprint.service';
import { Fingerprint } from '../models/fingerprint.model';

import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
  selector: 'app-capture',
  templateUrl: './capture.component.html',
  styleUrls: ['./capture.component.css']
})
export class CaptureComponent  {
  displayCustomerAccountDetails: boolean = false;
  disableVerifyButton: boolean = true;
  imageURL :any='assets/7d1p.gif'
  fingerprint1: any;
  base64data: any;
  templateRes: any;
  constructor(private fingerprintService: FingerprintService,private sanitizer: DomSanitizer){}
  openPopup(): void {
   
  }
  closePopup(): void {
 
  }
  biometric() {

  }
  async capture() {
    this.fingerprint1 = await this.fingerprintService.capture();
    if (this.fingerprint1) {
      this.base64data = this.fingerprint1;
      const blobData = this.convertBase64ToBlob(this.base64data, 'image/png');
      const imageURL = URL.createObjectURL(blobData);
      this.imageURL = this.sanitizer.bypassSecurityTrustUrl(imageURL);
      this.templateRes = await this.createTemplate(this.base64data);
      this.disableVerifyButton = false;
    }
  
  }
  private convertBase64ToBlob(base64: string, type: string): Blob {
    const binary = atob(base64);
    const uint8Array = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      uint8Array[i] = binary.charCodeAt(i);
    }
    return new Blob([uint8Array], { type: type });
  }
  async createTemplate(base64data: any) {
    
  }

OnVerify() {
   

  }

}

