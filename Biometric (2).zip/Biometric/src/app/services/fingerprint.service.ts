import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Fingerprint } from '../models/fingerprint.model';


 const baseUrl3='https://localhost:8443/SGIFPCapture'

@Injectable({
  providedIn: 'root'
})
export class FingerprintService {
  constructor(private http: HttpClient) { }
  public async capture(): Promise<any> {
    let header_node = {
      headers: new HttpHeaders(
          { 'rejectUnauthorized': 'false' })
      };
    let arrayBuffer : any =await this.http.get(baseUrl3).toPromise();
    
    
     console.log(arrayBuffer["BMPBase64"]);
     console.log();
     
    return arrayBuffer["BMPBase64"];

  }


  

}
